/**
 * Ticket 0103 — Five-world navigation.
 *
 * Spec 828–838: Career, Assets, Advance/Life (centre), Relationships, Activities.
 *
 * This is a small hand-written navigator rather than a navigation library. The
 * app's model is genuinely simple — five roots, each with a push stack of leaf
 * screens — and the central Advance control needs a tab bar that no library's
 * default renders. A custom navigator is less code here than configuring one,
 * and it keeps the shell dependency-free while the visual identity is still
 * being decided.
 *
 * Each world keeps its own stack, so switching worlds and coming back returns
 * you where you were.
 */

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

export const WORLDS = ['career', 'assets', 'life', 'relationships', 'activities'] as const;
export type World = (typeof WORLDS)[number];

/** Leaf screens pushed on top of a world root. */
export type ScreenKey =
  | 'mindBody'
  | 'doctor'
  | 'relocate'
  | 'finances'
  | 'investments'
  | 'homes'
  | 'vehicles'
  | 'businesses'
  | 'collections'
  | 'shopping'
  | 'family'
  | 'friends'
  /** Ticket 0206. One person: what they remember, and what you can do. */
  | 'person'
  /** Ticket 0204. School extracurriculars — join as many as you can carry. */
  | 'schoolActivities'
  /** Ticket 0206b. One team or club: how it is going, and practice. */
  | 'activity'
  /** Ticket 0206b. Odd jobs a child can actually do for money. */
  | 'gigs'
  /** Ticket 0207. Who there is, who there was, and where you stand. */
  | 'love'
  /** Ticket 0208. One child: how they are doing, and what they cost. */
  | 'child'
  /** Ticket 0209. One of your own parents, and what you can ask them for. */
  | 'parent'
  /** Ticket 0210. What is going this year, and the odds on each of it. */
  | 'jobs'
  /**
   * Ticket 0210b. ONE job, before you apply for it.
   *
   * Review: "when I click on a job, it automatically hires me. That should not
   * be the case." A listing opens this; applying is a separate press.
   */
  | 'jobOffer'
  /** Ticket 0210b. What is on offer to study, and what it costs. */
  | 'college'
  /**
   * Ticket 0210. The people at work.
   *
   * Spec 1305–1309: the Relationships screen is Family and Friends, and
   * "professional relationships stay in their own worlds". So colleagues are
   * reached from Career and appear nowhere else until one becomes a friend.
   */
  | 'colleagues'
  | 'debug';

export interface Route {
  readonly screen: ScreenKey;
  readonly title: string;
  /**
   * Who this screen is about, for routes that are about one person (0206).
   *
   * Carried on the route rather than in a store: the back stack already
   * remembers where the player was, and a second place holding "the person
   * being looked at" is a second thing that can disagree with it.
   */
  readonly personId?: string;
  /** Which activity this screen is about (0206b). Same reasoning as personId. */
  readonly activityId?: string;
  /** Which job this screen is about (0210b). Same reasoning again. */
  readonly jobId?: string;
}

type Stacks = Record<World, Route[]>;

const EMPTY_STACKS: Stacks = {
  career: [],
  assets: [],
  life: [],
  relationships: [],
  activities: [],
};

interface NavigationContextValue {
  readonly world: World;
  readonly stack: readonly Route[];
  readonly current: Route | null;
  readonly selectWorld: (world: World) => void;
  readonly push: (route: Route) => void;
  readonly pop: () => void;
  readonly popToRoot: () => void;
  /**
   * Leave the current world and return to Life without advancing a year.
   * The world's stack is reset, because closing means "done here".
   */
  readonly closeToLife: () => void;
}

const NavigationContext = createContext<NavigationContextValue | null>(null);

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [world, setWorld] = useState<World>('life');
  const [stacks, setStacks] = useState<Stacks>(EMPTY_STACKS);

  const selectWorld = useCallback((next: World) => {
    // Tapping the world you are already in returns to its root — the standard
    // mobile convention, and the cheapest way out of a deep stack.
    setStacks((current) => {
      setWorld((activeWorld) => {
        if (activeWorld === next) {
          setStacks((inner) => ({ ...inner, [next]: [] }));
        }
        return next;
      });
      return current;
    });
  }, []);

  const push = useCallback((route: Route) => {
    setWorld((activeWorld) => {
      setStacks((current) => ({
        ...current,
        [activeWorld]: [...current[activeWorld], route],
      }));
      return activeWorld;
    });
  }, []);

  const pop = useCallback(() => {
    setWorld((activeWorld) => {
      setStacks((current) => ({
        ...current,
        [activeWorld]: current[activeWorld].slice(0, -1),
      }));
      return activeWorld;
    });
  }, []);

  const popToRoot = useCallback(() => {
    setWorld((activeWorld) => {
      setStacks((current) => ({ ...current, [activeWorld]: [] }));
      return activeWorld;
    });
  }, []);

  const closeToLife = useCallback(() => {
    setWorld((activeWorld) => {
      // Clear unconditionally, including when already on Life. The developer
      // screen is pushed onto Life's own stack, and an `activeWorld !== 'life'`
      // guard here left it with no way out.
      setStacks((current) => ({ ...current, [activeWorld]: [], life: [] }));
      return 'life';
    });
  }, []);

  const stack = stacks[world];

  const value = useMemo<NavigationContextValue>(
    () => ({
      world,
      stack,
      current: stack.length > 0 ? (stack[stack.length - 1] as Route) : null,
      selectWorld,
      push,
      pop,
      popToRoot,
      closeToLife,
    }),
    [world, stack, selectWorld, push, pop, popToRoot, closeToLife],
  );

  return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
}

export function useNavigation(): NavigationContextValue {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used inside a NavigationProvider');
  }
  return context;
}

/**
 * Screen-header titles. These can be longer than the tab labels because the
 * header has the full screen width — which is why Relationships gets its real
 * name here even though the tab has to say "People".
 */
export const WORLD_TITLES: Record<World, string> = {
  career: 'Career',
  assets: 'Assets',
  life: 'Life',
  relationships: 'Relationships',
  activities: 'Activities',
};

/**
 * Tab labels.
 *
 * These name the five worlds of spec 828–838 in the player's language. They are
 * constrained to a fifth of the screen, which is the only reason Relationships
 * appears as "People" here while the header above says the full word.
 */
export const WORLD_LABELS: Record<World, string> = {
  career: 'Career',
  assets: 'Assets',
  life: 'Life',
  relationships: 'People',
  activities: 'Activities',
};
